Instructions:

Both the folders you see in this archive need to go onto your SD root. You need a Homebrew Channel installed on your Wii for this to all work.

When you copy the folders correctly to the SD card, a new application will appear in the Homebrew Channel called "Wiimmfi Patcher".

When you run it, all you must do is insert a disc and wait, and it will attempt to automatically patch your game, and then run it.

Once your game is running, simply try to connect to Nintendo WFC. If you get error codes, check http://nas.wiimmfi.de/error to find out why. Error Code 60000 means you need a new friend code. But, if you desperately want to use your old friend code, try using this tool: http://download.wiimm.de/wiimmfi/pidtool-alias-profile-dumper.zip (run it in the Homebrew Channel) and wait approximately 24 hours. Your old friend code may then start working!

Naturally, all patches are temporary, as the Wii can't write data to a disc. But it's suprising how many people think it can... So you must run this every time you wish to play on Wiimmfi.



Report problems with the app to MrBean35000vr.


CHANGELOG

v0.5

- Removes Gamestats skip code, it's no longer required.
- Fixes a bug where not all strings in Mario Kart Wii would correctly patch!
- Inserts a call that resets the wireless before booting. This makes it work from FlashHax.
- Removed all dependencies on files on the SD card! Other than itself, of course.

v0.4

- Animal Crossing no longer runs horrendously slow.
- Mario Strikers Charged (USA/PAL) now have an inbuilt Gamestats skip code to bypass the missing server (fix Error 98020).


v0.3

- Now a standalone app.
- Even better compatability with games.
- Super Smash Bros. Brawl no longer runs horrendously slow.


v0.2

- Changed patching method to fix the problems of v0.1.
- Improved compatability with games that aren't Mario Kart.


v0.1

- Initial version.
- Uses BrainSlug.
- Patching method not very robust yet.